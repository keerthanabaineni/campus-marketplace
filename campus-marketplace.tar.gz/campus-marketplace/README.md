# Campus Marketplace — Fair Claim Queue

## The problem I chose

Of everything in the brief (scattered listings, unclear availability, conflicts), I focused on **one**:

> *Multiple people try to claim the same item, and nobody can tell who was first or whether it is still available.*

Today the "winner" is whoever the seller happens to reply to in a chat. That feels arbitrary, and a
buyer who silently disappears blocks everyone behind them. This project makes claiming **fair**
(first-come-first-served, decided by the server), **transparent** (everyone sees status and their
queue position; every decision is logged), and **self-healing** (no-shows time out automatically).

## How it works

```
Listing:  OPEN ──claim──▶ HELD ──seller confirms──▶ SOLD        (seller may CANCEL any time before SOLD)
Claim:    QUEUED ─▶ HOLDING ─▶ COMPLETED
                 └▶ EXPIRED (hold timed out) / WITHDRAWN (buyer left) / SKIPPED (seller passed) / CLOSED
```

1. A buyer **claims** a listing. The claim joins a FIFO queue; order is the claim row id, assigned
   inside a serialised transaction, so there is exactly one answer to "who was first".
2. The head of the queue gets an exclusive **hold** for `hold_minutes` (set per listing, default 24h).
3. The seller **completes** the sale with the holder, which sets the listing to SOLD and closes the queue.
4. If the holder doesn't finish in time the hold **expires** and the next person is promoted
   automatically. The seller can also **skip** an unresponsive holder, and buyers can **withdraw**.
5. Every state change is written to an append-only **audit trail** (`GET /listings/{id}/events`),
   so a dispute can be answered from the record rather than from memory.

### Key design decisions
| Decision | Why |
|---|---|
| **Lazy expiry** ("settle" on every read/write) instead of a background job | No scheduler to run or fail; behaviour is deterministic and unit-testable with an injected clock. |
| Promoted buyer's clock starts at the **previous hold's expiry**, not "when someone looked" | Otherwise a quiet listing would give the next buyer extra time. Tested. |
| **DB-level uniqueness** (one HOLDING per listing, one active claim per buyer per listing) | Correctness doesn't depend only on app code; double-holds are impossible even if there's a bug. |
| `BEGIN IMMEDIATE` per write | Serialises writers so concurrent claims get a clean total order. Tested with 20 threads. |
| Only the **seller** can see who the holder is; buyers see only status, queue length and their own position | Transparency about *process* without exposing other students' identities. |

### Deliberately not built
Search/categories, images, payments, ratings, chat, notifications, real authentication, admin UI.
They're valuable, but each is a separate problem; the goal here was to get one hard thing right.
Possible next step: a penalty or lower queue priority for repeat no-shows.

## Assumptions
- Money and the handoff happen offline; the **seller's confirmation** is the source of truth for "sold".
- Identity is out of scope: callers send `X-User-Id` (create users via `POST /users`). A real system would use campus SSO.
- One unit per listing. Hold duration is chosen by the seller (e.g. 60 min for a book, 24h for a sofa).
- A buyer whose hold expired may re-join, but goes to the back of the queue.
- SQLite is sufficient for a single-campus scale; the logic is a thin layer that ports to Postgres (`SELECT … FOR UPDATE` in place of `BEGIN IMMEDIATE`).

## Run it

Requires Python 3.10+.

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

pytest -q                                   # 12 tests, incl. a 20-thread race
uvicorn app.main:app --reload               # then open http://localhost:8000
```
- **Website:** http://localhost:8000 — click **Load demo data**, then use the *Acting as* dropdown to switch
  between students (seller, buyers) and try claiming, queueing, withdrawing, skipping and completing a sale.
- **API docs (Swagger):** http://localhost:8000/docs
The database file (`marketplace.db`) is created automatically; override with `MARKETPLACE_DB=/path/x.db`.

## Example session

```bash
B=http://localhost:8000
curl -s -XPOST $B/users -H 'content-type: application/json' -d '{"name":"Seller"}'   # id 1
curl -s -XPOST $B/users -H 'content-type: application/json' -d '{"name":"Asha"}'     # id 2
curl -s -XPOST $B/users -H 'content-type: application/json' -d '{"name":"Ravi"}'     # id 3

curl -s -XPOST $B/listings -H 'X-User-Id: 1' -H 'content-type: application/json' \
     -d '{"title":"Calculus textbook","price_cents":30000,"hold_minutes":60}'

curl -s -XPOST $B/listings/1/claims -H 'X-User-Id: 2'   # Asha -> position 0 (holding)
curl -s -XPOST $B/listings/1/claims -H 'X-User-Id: 3'   # Ravi -> position 1
curl -s $B/listings/1 -H 'X-User-Id: 3'                 # Ravi sees his position + hold expiry of the holder
curl -s -XPOST $B/listings/1/skip-holder -H 'X-User-Id: 1'   # seller passes on Asha -> Ravi now holds
curl -s -XPOST $B/listings/1/complete    -H 'X-User-Id: 1'   # sold to Ravi
curl -s $B/listings/1/events                                 # full audit trail
```

## API
| Method & path | Who | Purpose |
|---|---|---|
| `GET /users`, `POST /users` | anyone | list / create users |
| `POST /listings` | seller | create listing (`title`, `price_cents`, `hold_minutes`) |
| `GET /listings[?status=]`, `GET /listings/{id}` | anyone | availability, queue length, *my* position |
| `POST /listings/{id}/claims` | buyer | join queue |
| `DELETE /claims/{id}` | buyer | withdraw (promotes next if holding) |
| `POST /listings/{id}/complete` | seller | confirm sale to current holder |
| `POST /listings/{id}/skip-holder` | seller | pass on no-show holder |
| `POST /listings/{id}/cancel` | seller | withdraw listing |
| `GET /listings/{id}/events` | anyone | audit trail |

## Layout
```
app/db.py        schema + transaction helper (constraints live here)
app/service.py   core logic: queue, holds, expiry, audit trail
app/main.py      FastAPI interface (also serves the website)
app/static/index.html   single-page website (plain HTML/CSS/JS, no build step)
tests/           unit tests (fake clock) + API smoke test
```
