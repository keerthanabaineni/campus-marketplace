"""Core logic: a fair, FIFO claim queue with time-limited holds.

Lifecycle of a listing:  OPEN -> HELD -> SOLD     (or CANCELLED)
Lifecycle of a claim:    QUEUED -> HOLDING -> COMPLETED
                         (or EXPIRED / WITHDRAWN / SKIPPED / CLOSED)

Rules
  * Buyers join a queue; arrival order is decided server-side, inside a
    serialised transaction, so there is exactly one answer to "who was first".
  * Only the head of the queue holds the item, for `hold_minutes`.
  * If the holder doesn't complete in time, the hold expires and the next
    person is promoted automatically.
  * Expiry is evaluated lazily on every read/write ("settle"), so there is no
    background worker and behaviour is deterministic. A promoted buyer's clock
    starts when the previous hold expired, not when someone happened to look.
"""
import time
from .db import tx


class MarketError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.message, self.status = message, status


def _now():
    return int(time.time())


class Marketplace:
    def __init__(self, db_path, clock=_now):
        self.db, self.clock = db_path, clock

    # ---------- helpers ----------
    @staticmethod
    def _event(conn, listing_id, type_, at, claim_id=None, actor_id=None, detail=""):
        conn.execute(
            "INSERT INTO events(listing_id,claim_id,actor_id,type,detail,at) VALUES(?,?,?,?,?,?)",
            (listing_id, claim_id, actor_id, type_, detail, at))

    def _listing(self, conn, listing_id):
        row = conn.execute("SELECT * FROM listings WHERE id=?", (listing_id,)).fetchone()
        if not row:
            raise MarketError("Listing not found", 404)
        return row

    def _promote(self, conn, listing, start):
        """Give the hold to the next queued buyer, or reopen the listing."""
        nxt = conn.execute(
            "SELECT * FROM claims WHERE listing_id=? AND status='QUEUED' ORDER BY id LIMIT 1",
            (listing["id"],)).fetchone()
        if nxt:
            exp = start + listing["hold_minutes"] * 60
            conn.execute("UPDATE claims SET status='HOLDING',hold_started_at=?,hold_expires_at=? WHERE id=?",
                         (start, exp, nxt["id"]))
            conn.execute("UPDATE listings SET status='HELD' WHERE id=?", (listing["id"],))
            self._event(conn, listing["id"], "HOLD_STARTED", start, nxt["id"], nxt["buyer_id"],
                        f"hold expires at {exp}")
        else:
            conn.execute("UPDATE listings SET status='OPEN' WHERE id=?", (listing["id"],))

    def _settle(self, conn, listing_id):
        """Expire overdue holds (possibly several in a row) and promote."""
        now = self.clock()
        while True:
            listing = self._listing(conn, listing_id)
            if listing["status"] != "HELD":
                return listing
            h = conn.execute("SELECT * FROM claims WHERE listing_id=? AND status='HOLDING'",
                             (listing_id,)).fetchone()
            if h and h["hold_expires_at"] > now:
                return listing
            if h:
                conn.execute("UPDATE claims SET status='EXPIRED' WHERE id=?", (h["id"],))
                self._event(conn, listing_id, "HOLD_EXPIRED", h["hold_expires_at"], h["id"], h["buyer_id"])
                self._promote(conn, listing, h["hold_expires_at"])
            else:  # defensive: HELD without holder
                self._promote(conn, listing, now)

    @staticmethod
    def _position(conn, claim):
        if claim["status"] == "HOLDING":
            return 0
        if claim["status"] != "QUEUED":
            return None
        return conn.execute("SELECT COUNT(*) FROM claims WHERE listing_id=? AND status='QUEUED' AND id<?",
                            (claim["listing_id"], claim["id"])).fetchone()[0] + 1

    def _view(self, conn, listing, viewer_id=None):
        qlen = conn.execute("SELECT COUNT(*) FROM claims WHERE listing_id=? AND status='QUEUED'",
                            (listing["id"],)).fetchone()[0]
        holder = conn.execute("SELECT * FROM claims WHERE listing_id=? AND status='HOLDING'",
                              (listing["id"],)).fetchone()
        out = {k: listing[k] for k in ("id", "seller_id", "title", "description",
                                      "price_cents", "hold_minutes", "status", "created_at")}
        out["queue_length"] = qlen
        out["held_until"] = holder["hold_expires_at"] if holder else None
        if viewer_id:
            mine = conn.execute(
                "SELECT * FROM claims WHERE listing_id=? AND buyer_id=? AND status IN ('QUEUED','HOLDING')",
                (listing["id"], viewer_id)).fetchone()
            out["my_claim"] = ({"claim_id": mine["id"], "status": mine["status"],
                                "position": self._position(conn, mine),
                                "hold_expires_at": mine["hold_expires_at"]} if mine else None)
        if viewer_id == listing["seller_id"] and holder:  # only seller sees who holds
            out["holder"] = {"claim_id": holder["id"], "buyer_id": holder["buyer_id"]}
        return out

    # ---------- users & listings ----------
    def create_user(self, name):
        if not name.strip():
            raise MarketError("Name required")
        with tx(self.db) as c:
            return {"id": c.execute("INSERT INTO users(name) VALUES(?)", (name.strip(),)).lastrowid,
                    "name": name.strip()}

    def list_users(self):
        with tx(self.db) as c:
            return [dict(r) for r in c.execute("SELECT id,name FROM users ORDER BY id")]

    def _require_user(self, conn, user_id):
        if not conn.execute("SELECT 1 FROM users WHERE id=?", (user_id,)).fetchone():
            raise MarketError("Unknown user", 401)

    def create_listing(self, seller_id, title, price_cents, description="", hold_minutes=1440):
        if not title.strip() or price_cents < 0 or hold_minutes <= 0:
            raise MarketError("Invalid listing")
        with tx(self.db) as c:
            self._require_user(c, seller_id)
            now = self.clock()
            lid = c.execute(
                "INSERT INTO listings(seller_id,title,description,price_cents,hold_minutes,status,created_at)"
                " VALUES(?,?,?,?,?,'OPEN',?)",
                (seller_id, title.strip(), description, price_cents, hold_minutes, now)).lastrowid
            self._event(c, lid, "LISTED", now, actor_id=seller_id)
            return self._view(c, self._listing(c, lid), seller_id)

    def list_listings(self, status=None, viewer_id=None):
        with tx(self.db) as c:
            ids = [r[0] for r in c.execute("SELECT id FROM listings ORDER BY id DESC")]
            views = [self._view(c, self._settle(c, i), viewer_id) for i in ids]
        return [v for v in views if status is None or v["status"] == status]

    def get_listing(self, listing_id, viewer_id=None):
        with tx(self.db) as c:
            return self._view(c, self._settle(c, listing_id), viewer_id)

    # ---------- buyer actions ----------
    def claim(self, listing_id, buyer_id):
        with tx(self.db) as c:
            self._require_user(c, buyer_id)
            listing = self._settle(c, listing_id)
            if listing["seller_id"] == buyer_id:
                raise MarketError("You can't claim your own listing", 403)
            if listing["status"] in ("SOLD", "CANCELLED"):
                raise MarketError(f"Listing is {listing['status'].lower()}", 409)
            now = self.clock()
            try:
                cid = c.execute("INSERT INTO claims(listing_id,buyer_id,status,created_at) VALUES(?,?,'QUEUED',?)",
                                (listing_id, buyer_id, now)).lastrowid
            except Exception:
                raise MarketError("You already have an active claim on this listing", 409)
            self._event(c, listing_id, "CLAIM_QUEUED", now, cid, buyer_id)
            if listing["status"] == "OPEN":
                self._promote(c, listing, now)
            return self._view(c, self._listing(c, listing_id), buyer_id)

    def withdraw(self, claim_id, buyer_id):
        with tx(self.db) as c:
            claim = c.execute("SELECT * FROM claims WHERE id=?", (claim_id,)).fetchone()
            if not claim:
                raise MarketError("Claim not found", 404)
            if claim["buyer_id"] != buyer_id:
                raise MarketError("Not your claim", 403)
            self._settle(c, claim["listing_id"])
            claim = c.execute("SELECT * FROM claims WHERE id=?", (claim_id,)).fetchone()
            if claim["status"] not in ("QUEUED", "HOLDING"):
                raise MarketError(f"Claim already {claim['status'].lower()}", 409)
            now = self.clock()
            was_holding = claim["status"] == "HOLDING"
            c.execute("UPDATE claims SET status='WITHDRAWN' WHERE id=?", (claim_id,))
            self._event(c, claim["listing_id"], "CLAIM_WITHDRAWN", now, claim_id, buyer_id)
            if was_holding:
                self._promote(c, self._listing(c, claim["listing_id"]), now)
            return self._view(c, self._listing(c, claim["listing_id"]), buyer_id)

    # ---------- seller actions ----------
    def _seller_listing(self, conn, listing_id, seller_id):
        listing = self._settle(conn, listing_id)
        if listing["seller_id"] != seller_id:
            raise MarketError("Only the seller can do this", 403)
        return listing

    def complete(self, listing_id, seller_id):
        """Seller confirms the item was handed to the current holder."""
        with tx(self.db) as c:
            self._seller_listing(c, listing_id, seller_id)
            h = c.execute("SELECT * FROM claims WHERE listing_id=? AND status='HOLDING'", (listing_id,)).fetchone()
            if not h:
                raise MarketError("No active holder to complete the sale with", 409)
            now = self.clock()
            c.execute("UPDATE claims SET status='COMPLETED' WHERE id=?", (h["id"],))
            c.execute("UPDATE claims SET status='CLOSED' WHERE listing_id=? AND status='QUEUED'", (listing_id,))
            c.execute("UPDATE listings SET status='SOLD' WHERE id=?", (listing_id,))
            self._event(c, listing_id, "SOLD", now, h["id"], seller_id, f"buyer {h['buyer_id']}")
            return self._view(c, self._listing(c, listing_id), seller_id)

    def skip_holder(self, listing_id, seller_id, reason=""):
        """Seller passes on a no-show / unresponsive holder; next in line is promoted."""
        with tx(self.db) as c:
            self._seller_listing(c, listing_id, seller_id)
            h = c.execute("SELECT * FROM claims WHERE listing_id=? AND status='HOLDING'", (listing_id,)).fetchone()
            if not h:
                raise MarketError("No active holder", 409)
            now = self.clock()
            c.execute("UPDATE claims SET status='SKIPPED' WHERE id=?", (h["id"],))
            self._event(c, listing_id, "HOLDER_SKIPPED", now, h["id"], seller_id, reason)
            self._promote(c, self._listing(c, listing_id), now)
            return self._view(c, self._listing(c, listing_id), seller_id)

    def cancel(self, listing_id, seller_id):
        with tx(self.db) as c:
            listing = self._seller_listing(c, listing_id, seller_id)
            if listing["status"] == "SOLD":
                raise MarketError("Already sold", 409)
            c.execute("UPDATE claims SET status='CLOSED' WHERE listing_id=? AND status IN ('QUEUED','HOLDING')",
                      (listing_id,))
            c.execute("UPDATE listings SET status='CANCELLED' WHERE id=?", (listing_id,))
            self._event(c, listing_id, "CANCELLED", self.clock(), actor_id=seller_id)
            return self._view(c, self._listing(c, listing_id), seller_id)

    # ---------- transparency ----------
    def events(self, listing_id):
        with tx(self.db) as c:
            self._settle(c, listing_id)
            return [dict(r) for r in c.execute(
                "SELECT type,claim_id,actor_id,detail,at FROM events WHERE listing_id=? ORDER BY id",
                (listing_id,))]
