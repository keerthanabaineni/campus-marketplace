"""SQLite storage. Every write runs in a BEGIN IMMEDIATE transaction, which
serialises writers - this is what makes 'who claimed first' well defined."""
import sqlite3
from contextlib import contextmanager

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS listings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    seller_id INTEGER NOT NULL REFERENCES users(id),
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    price_cents INTEGER NOT NULL CHECK (price_cents >= 0),
    hold_minutes INTEGER NOT NULL CHECK (hold_minutes > 0),
    status TEXT NOT NULL CHECK (status IN ('OPEN','HELD','SOLD','CANCELLED')),
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS claims (
    id INTEGER PRIMARY KEY AUTOINCREMENT,      -- id order == arrival order
    listing_id INTEGER NOT NULL REFERENCES listings(id),
    buyer_id INTEGER NOT NULL REFERENCES users(id),
    status TEXT NOT NULL CHECK (status IN
        ('QUEUED','HOLDING','COMPLETED','EXPIRED','WITHDRAWN','SKIPPED','CLOSED')),
    created_at INTEGER NOT NULL,
    hold_started_at INTEGER,
    hold_expires_at INTEGER
);
-- DB-level guarantees, independent of application logic:
CREATE UNIQUE INDEX IF NOT EXISTS one_holder_per_listing
    ON claims(listing_id) WHERE status = 'HOLDING';
CREATE UNIQUE INDEX IF NOT EXISTS one_active_claim_per_buyer
    ON claims(listing_id, buyer_id) WHERE status IN ('QUEUED','HOLDING');
CREATE TABLE IF NOT EXISTS events (            -- append-only audit trail
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    listing_id INTEGER NOT NULL,
    claim_id INTEGER,
    actor_id INTEGER,
    type TEXT NOT NULL,
    detail TEXT NOT NULL DEFAULT '',
    at INTEGER NOT NULL
);
"""


def connect(path):
    conn = sqlite3.connect(path, timeout=15, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db(path):
    conn = connect(path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript(SCHEMA)
    conn.close()


@contextmanager
def tx(path):
    conn = connect(path)
    try:
        conn.execute("BEGIN IMMEDIATE")
        yield conn
        conn.execute("COMMIT")
    except BaseException:
        if conn.in_transaction:
            conn.execute("ROLLBACK")
        raise
    finally:
        conn.close()
