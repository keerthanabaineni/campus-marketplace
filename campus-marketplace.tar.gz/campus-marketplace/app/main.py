"""HTTP API. Auth is deliberately out of scope: callers identify themselves
with an `X-User-Id` header (see README assumptions)."""
import os
from fastapi import FastAPI, Header, Request
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel, Field
from .db import init_db
from .service import Marketplace, MarketError

DB_PATH = os.environ.get("MARKETPLACE_DB", "marketplace.db")
init_db(DB_PATH)
market = Marketplace(DB_PATH)
app = FastAPI(title="Campus Marketplace - Fair Claim Queue")


@app.exception_handler(MarketError)
async def _err(_: Request, e: MarketError):
    return JSONResponse({"error": e.message}, status_code=e.status)


class UserIn(BaseModel):
    name: str


class ListingIn(BaseModel):
    title: str
    price_cents: int = Field(ge=0)
    description: str = ""
    hold_minutes: int = Field(default=1440, gt=0)


class SkipIn(BaseModel):
    reason: str = ""


def uid(x_user_id: int | None):
    if x_user_id is None:
        raise MarketError("X-User-Id header required", 401)
    return x_user_id


@app.get("/", include_in_schema=False)
def home():
    return FileResponse(os.path.join(os.path.dirname(__file__), "static", "index.html"))


@app.get("/users")
def users():
    return market.list_users()


@app.post("/users", status_code=201)
def create_user(b: UserIn):
    return market.create_user(b.name)


@app.post("/listings", status_code=201)
def create_listing(b: ListingIn, x_user_id: int | None = Header(None)):
    return market.create_listing(uid(x_user_id), b.title, b.price_cents, b.description, b.hold_minutes)


@app.get("/listings")
def list_listings(status: str | None = None, x_user_id: int | None = Header(None)):
    return market.list_listings(status, x_user_id)


@app.get("/listings/{lid}")
def get_listing(lid: int, x_user_id: int | None = Header(None)):
    return market.get_listing(lid, x_user_id)


@app.post("/listings/{lid}/claims", status_code=201)
def claim(lid: int, x_user_id: int | None = Header(None)):
    return market.claim(lid, uid(x_user_id))


@app.delete("/claims/{cid}")
def withdraw(cid: int, x_user_id: int | None = Header(None)):
    return market.withdraw(cid, uid(x_user_id))


@app.post("/listings/{lid}/complete")
def complete(lid: int, x_user_id: int | None = Header(None)):
    return market.complete(lid, uid(x_user_id))


@app.post("/listings/{lid}/skip-holder")
def skip(lid: int, b: SkipIn = SkipIn(), x_user_id: int | None = Header(None)):
    return market.skip_holder(lid, uid(x_user_id), b.reason)


@app.post("/listings/{lid}/cancel")
def cancel(lid: int, x_user_id: int | None = Header(None)):
    return market.cancel(lid, uid(x_user_id))


@app.get("/listings/{lid}/events")
def events(lid: int):
    return market.events(lid)
