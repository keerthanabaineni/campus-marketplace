import threading
import pytest
from app.db import init_db
from app.service import Marketplace, MarketError


class Clock:
    def __init__(self): self.t = 1_000_000
    def __call__(self): return self.t
    def advance(self, minutes): self.t += minutes * 60


@pytest.fixture
def env(tmp_path):
    path = str(tmp_path / "t.db")
    init_db(path)
    clock = Clock()
    m = Marketplace(path, clock)
    users = [m.create_user(n)["id"] for n in ["seller", "a", "b", "c"]]
    listing = m.create_listing(users[0], "Calculus book", 30000, hold_minutes=60)
    return m, clock, users, listing["id"]


def test_first_claimer_holds_others_queue_in_order(env):
    m, _, (s, a, b, c), lid = env
    assert m.claim(lid, a)["my_claim"]["position"] == 0
    assert m.claim(lid, b)["my_claim"]["position"] == 1
    assert m.claim(lid, c)["my_claim"]["position"] == 2
    v = m.get_listing(lid)
    assert v["status"] == "HELD" and v["queue_length"] == 2


def test_duplicate_and_self_claims_rejected(env):
    m, _, (s, a, b, c), lid = env
    m.claim(lid, a)
    with pytest.raises(MarketError): m.claim(lid, a)
    with pytest.raises(MarketError): m.claim(lid, s)


def test_hold_expiry_promotes_next_and_clock_starts_at_prior_expiry(env):
    m, clock, (s, a, b, c), lid = env
    m.claim(lid, a); m.claim(lid, b); m.claim(lid, c)
    clock.advance(61)                      # a's hold lapsed 1 min ago
    v = m.get_listing(lid, b)
    assert v["my_claim"]["status"] == "HOLDING"
    assert v["my_claim"]["hold_expires_at"] == 1_000_000 + 120 * 60  # not "now + 60"
    clock.advance(200)                     # everyone lapses -> listing reopens
    assert m.get_listing(lid)["status"] == "OPEN"


def test_expired_buyer_can_rejoin_at_back(env):
    m, clock, (s, a, b, c), lid = env
    m.claim(lid, a); m.claim(lid, b)
    clock.advance(61)
    assert m.claim(lid, a)["my_claim"]["position"] == 1  # b holds now


def test_withdraw_holder_promotes_next(env):
    m, _, (s, a, b, c), lid = env
    ca = m.claim(lid, a)["my_claim"]["claim_id"]
    m.claim(lid, b)
    m.withdraw(ca, a)
    assert m.get_listing(lid, b)["my_claim"]["status"] == "HOLDING"
    with pytest.raises(MarketError): m.withdraw(ca, b)   # not yours


def test_seller_complete_closes_queue(env):
    m, _, (s, a, b, c), lid = env
    m.claim(lid, a); m.claim(lid, b)
    assert m.complete(lid, s)["status"] == "SOLD"
    with pytest.raises(MarketError): m.claim(lid, c)
    with pytest.raises(MarketError): m.complete(lid, a)  # non-seller


def test_skip_holder_and_cancel(env):
    m, _, (s, a, b, c), lid = env
    m.claim(lid, a); m.claim(lid, b)
    m.skip_holder(lid, s, "no-show")
    assert m.get_listing(lid, b)["my_claim"]["status"] == "HOLDING"
    assert m.cancel(lid, s)["status"] == "CANCELLED"
    assert m.get_listing(lid, b)["my_claim"] is None


def test_audit_trail_explains_what_happened(env):
    m, clock, (s, a, b, c), lid = env
    m.claim(lid, a); m.claim(lid, b); clock.advance(61); m.complete(lid, s)
    types = [e["type"] for e in m.events(lid)]
    assert types == ["LISTED", "CLAIM_QUEUED", "HOLD_STARTED", "CLAIM_QUEUED",
                     "HOLD_EXPIRED", "HOLD_STARTED", "SOLD"]


def test_only_seller_sees_holder_identity(env):
    m, _, (s, a, b, c), lid = env
    m.claim(lid, a)
    assert "holder" in m.get_listing(lid, s) and "holder" not in m.get_listing(lid, b)


def test_concurrent_claims_yield_exactly_one_holder(env):
    m, _, users, lid = env
    extra = [m.create_user(f"u{i}")["id"] for i in range(20)]
    results = []
    def go(u): results.append(m.claim(lid, u)["my_claim"]["position"])
    ts = [threading.Thread(target=go, args=(u,)) for u in extra]
    [t.start() for t in ts]; [t.join() for t in ts]
    assert sorted(results) == list(range(20))   # one holder (0), unique queue slots 1..19
