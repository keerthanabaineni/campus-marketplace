import importlib
from fastapi.testclient import TestClient


def test_http_flow(tmp_path, monkeypatch):
    monkeypatch.setenv("MARKETPLACE_DB", str(tmp_path / "api.db"))
    import app.main as main
    importlib.reload(main)
    c = TestClient(main.app)
    s, a, b = [c.post("/users", json={"name": n}).json()["id"] for n in ("s", "a", "b")]
    h = lambda u: {"X-User-Id": str(u)}
    lid = c.post("/listings", json={"title": "Desk", "price_cents": 50000}, headers=h(s)).json()["id"]
    assert c.post(f"/listings/{lid}/claims", headers=h(a)).json()["my_claim"]["position"] == 0
    r = c.post(f"/listings/{lid}/claims", headers=h(b))
    assert r.status_code == 201 and r.json()["my_claim"]["position"] == 1
    assert c.post(f"/listings/{lid}/claims", headers=h(b)).status_code == 409
    assert c.post(f"/listings/{lid}/complete", headers=h(a)).status_code == 403
    assert c.post(f"/listings/{lid}/complete", headers=h(s)).json()["status"] == "SOLD"
    assert c.get(f"/listings/{lid}/events").json()[-1]["type"] == "SOLD"
    assert c.post(f"/listings/{lid}/claims").status_code == 401


def test_website_and_users_endpoint(tmp_path, monkeypatch):
    monkeypatch.setenv("MARKETPLACE_DB", str(tmp_path / "web.db"))
    import app.main as main
    importlib.reload(main)
    c = TestClient(main.app)
    r = c.get("/")
    assert r.status_code == 200 and "Campus Marketplace" in r.text
    c.post("/users", json={"name": "Asha"})
    assert c.get("/users").json() == [{"id": 1, "name": "Asha"}]
